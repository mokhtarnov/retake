# Retakeem
Projet audiovisuel

A faire:
- menu connection
- menu prendre vidéo
- menu noté vidéo
- menu classement
